public interface Comparable {
    public int compareTo(Comparable other);
}
