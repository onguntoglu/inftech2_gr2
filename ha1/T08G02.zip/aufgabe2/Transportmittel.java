public interface Transportmittel{
    void beschleunigen(float geschwindigkeit);
}